package com.talentsprint.TaxiHub.controller;

public interface Provider {
	String DRIVER="com.mysql.jdbc.Driver";
	String CONNECTION_URL="jdbc:mysql://localhost:3306/tonocabs";
	String USERNAME="root";
	String PASSWORD="anuhya@1998";
}
