package com.talentsprint.TaxiHub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RegisterDAO {
	ConnectionDAO cdao = new ConnectionDAO();
	Connection conn = cdao.getCon();
	
	public boolean insertValidate(String user, String number, String password) throws SQLException {
		boolean status = true;
		String sql = "insert into user_registration values(?,?,?)";

			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setString(1, user);
			preparedStatement.setString(2, number);
			preparedStatement.setString(3, password);
			int i= preparedStatement.executeUpdate();
			if (i > 0) {
				Statement statement =conn.createStatement();
				String stm = "select * from user_registration";
				ResultSet rs = statement.executeQuery(stm);
				if(rs.next()){
					if(rs.getString(2).equals(number)){
						status = false;
					}
			    }
		    }
		return status;
	}
}
		/*	if(i>0){
				status = true;
			} else {
				status = false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;*/

