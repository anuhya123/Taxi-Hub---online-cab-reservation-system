package com.talentsprint.TaxiHub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LoginDAO {
	ConnectionDAO cdao = new ConnectionDAO();
	Connection conn = cdao.getCon();
		
	public  boolean validate(String number, String password) throws SQLException{
		boolean status = false;
		String DBPhone = null;
		String DBPassword = null;
		String sql = "select * from user_registration where phone_number =" +"'"+ number+"'";
		
		Statement statement = conn.prepareStatement(sql);
		//statement.setString(1, number);
		ResultSet resultSet = statement.executeQuery(sql);
		if (resultSet.next()){
			while (resultSet.next()) {
				DBPhone = resultSet.getString(2);
				DBPassword = resultSet.getString(3);
				if ((DBPhone.equals(number)) && (DBPassword.equals(password))) {
					status = true;
				} 
			}
		}
		return status;
	}
}
			
			
			
			/*if (resultSet.getString(3).equals(password)) {
				status = true;
			} else {
				status = false;
			}
		}
		return status;
	}
} */
		
